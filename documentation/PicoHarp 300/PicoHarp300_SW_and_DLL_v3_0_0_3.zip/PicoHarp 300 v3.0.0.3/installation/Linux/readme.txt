The PicoHarp software can also be used under Linux with Wine. 
Please see the manual for details. 
Using the PicoHarp software under Linux requires Libusb (see http://libusb.info).
Libusb is licensed under the LGPL which allows a fairly free use even in 
commercial projects. In order to comply with the LGPL terms a copy of the 
LGPL text is provided here in this folder.

